# 🏒 NHL Game Analytics & Win-Probability Model

[![CI](https://github.com/YOUR_USERNAME/nhl-analytics/actions/workflows/ci.yml/badge.svg)](https://github.com/YOUR_USERNAME/nhl-analytics/actions/workflows/ci.yml)
![Python](https://img.shields.io/badge/python-3.10%20%7C%203.11%20%7C%203.12-blue)
![License: MIT](https://img.shields.io/badge/license-MIT-green)
![Tests](https://img.shields.io/badge/tests-13%20passing-brightgreen)

An end-to-end data science pipeline that ingests NHL game data, models it in a
**SQLite analytics database**, engineers **leakage-aware** recent-form features,
and trains a **calibrated win-probability model** — wrapped in an interactive
**Streamlit dashboard** and validated by a **tested, CI-backed** codebase.

> The pipeline runs fully offline on a reproducible synthetic season (so anyone,
> including CI, can run it in one command) and ships a live **NHL public-API**
> ingestion path for real data.

---

## 📊 Headline results

Predicting the **home team to win** from each team's pre-game form, evaluated on
a **time-based hold-out** (the most recent 20% of games — never a random split):

| Model | Accuracy | ROC-AUC | Log loss | Brier |
|---|---|---|---|---|
| Baseline (always pick home) | 0.545 | 0.500 | 0.689 | 0.248 |
| Gradient Boosting | 0.617 | 0.654 | 0.667 | 0.235 |
| **Logistic Regression** | **0.640** | **0.668** | **0.646** | **0.227** |

The interpretable logistic model **wins outright** — the predictive signal here
is largely linear, so the extra capacity of gradient boosting buys nothing. It
lifts accuracy ~10 points over the home-pick baseline and produces
**well-calibrated** probabilities.

| ROC curves | Calibration | Feature drivers |
|---|---|---|
| ![ROC](reports/figures/roc_curves.png) | ![Calibration](reports/figures/calibration.png) | ![Importance](reports/figures/feature_importance.png) |

---

## 🧱 Architecture

```mermaid
flowchart LR
    A[Ingest<br/>synthetic or NHL API] --> B[SQLite database<br/>schema + indexes]
    B --> C[Analytical SQL<br/>CTEs + window functions]
    B --> D[Leakage-aware<br/>feature engineering]
    D --> E[Model training<br/>+ time-series CV]
    E --> F[Evaluation<br/>ROC / calibration / Brier]
    C --> G[Streamlit dashboard]
    F --> G
    F --> H[Report figures]
```

---

## 🚀 Quickstart

```bash
git clone https://github.com/YOUR_USERNAME/nhl-analytics.git
cd nhl-analytics
pip install -r requirements.txt

# Run the whole pipeline on the reproducible synthetic season
python -m scripts.run_pipeline

# Or pull real NHL data (needs internet)
python -m scripts.run_pipeline --source api

# Launch the interactive dashboard
streamlit run app/dashboard.py

# Run the test suite
pytest -q
```

A `Makefile` wraps these: `make run`, `make dashboard`, `make test`, `make lint`.

---

## 🗃️ The SQL layer

Data lands in a normalised SQLite schema (`sql/schema.sql`) — a `teams`
dimension plus `games` and `team_game_stats` fact tables with primary keys,
foreign keys, and indexes. The analytical queries in `sql/analytics_queries.sql`
are loaded by name and progress from simple aggregation to multi-CTE window
functions:

- **`standings`** — league table built with a `UNION ALL` over home/away results
- **`home_ice_advantage`** — per-season home-win rate and scoring splits
- **`team_efficiency`** — shooting %, power-play %, and puck-management joins
- **`rolling_form`** — trailing 10-game win % via `AVG() OVER (PARTITION BY ... ROWS BETWEEN 9 PRECEDING AND CURRENT ROW)`
- **`biggest_upsets`** — ranked road blowouts using `RANK() OVER (...)`

---

## 🔬 Modelling methodology

**No leakage, by construction.** Games are processed in chronological order;
every feature for a game is computed *only* from that team's earlier games. The
update to each team's running history happens strictly *after* the row is
recorded ([`src/features.py`](src/features.py)). This is enforced by a unit test.

**Features** are home-minus-away differentials of rolling win %, rolling goals
for / against / differential, season-to-date win %, and rest-day advantage.

**Honest evaluation.** The hold-out is the most recent 20% of games (a temporal
split, not random), and cross-validation uses `TimeSeriesSplit`. Metrics span
ranking (ROC-AUC), accuracy, and probability quality (log loss, Brier score),
because for a forecasting task a *calibrated* 60% beats an overconfident 90%.

---

## ⚠️ Honest limitations

- **Synthetic by default.** Headline numbers come from a latent-strength
  simulator. On *real* NHL data, form-only models typically land around
  **0.60 AUC** — the league is far more balanced than any simulation. Run with
  `--source api` to see real-world performance.
- **Correlated coefficients.** Rolling and season win % are collinear, so their
  individual logistic coefficients are unstable (the negative rolling-win-pct
  sign is an artifact of that). Permutation importance or stronger
  regularization would give cleaner attributions.
- **No player-level or in-game state** (injuries, goalie starts, score effects),
  which are where the next accuracy gains live.

## 🔭 Next steps

Goalie-adjusted features · Elo / Glicko team ratings as priors · isotonic
probability calibration · expand the API path to multi-season backfill.

---

## 📁 Project structure

```
nhl-analytics/
├── src/
│   ├── ingest.py        # NHL API client + reproducible synthetic generator
│   ├── database.py      # SQLite schema loader & query helpers
│   ├── queries.py       # named-query loader for sql/analytics_queries.sql
│   ├── features.py      # leakage-aware feature engineering
│   ├── model.py         # training, time-series CV, evaluation
│   └── visualize.py     # report figures
├── sql/                 # schema.sql + analytics_queries.sql
├── app/dashboard.py     # Streamlit app
├── scripts/run_pipeline.py
├── tests/               # 13 tests (pytest)
└── .github/workflows/ci.yml
```

---

*Built by Antonio — MS Data Science, DePaul University. Lifelong Blackhawks fan;
the accent color is not a coincidence.*
