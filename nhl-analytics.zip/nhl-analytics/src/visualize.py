"""Visualisations for the analytics report.

All figures are saved to ``reports/figures`` at a consistent size and DPI so
they drop cleanly into a README or a slide deck.
"""

from __future__ import annotations

import matplotlib

matplotlib.use("Agg")  # headless backend so figures render in CI

import matplotlib.pyplot as plt
import pandas as pd
from sklearn.calibration import calibration_curve

from . import config, features as feat, model as model_mod

plt.rcParams.update(
    {
        "figure.dpi": 120,
        "savefig.bbox": "tight",
        "axes.grid": True,
        "grid.alpha": 0.3,
        "font.size": 11,
    }
)

_ACCENT = "#C8102E"  # Blackhawks red, naturally


def plot_standings(standings: pd.DataFrame, top_n: int = 12) -> None:
    """Horizontal bar chart of the top teams by points."""
    top = standings.head(top_n).iloc[::-1]
    fig, ax = plt.subplots(figsize=(8, 6))
    colors = [_ACCENT if abbrev == "CHI" else "#1f3a5f" for abbrev in top["abbrev"]]
    ax.barh(top["abbrev"], top["points"], color=colors)
    ax.set_xlabel("Points")
    ax.set_title(f"Top {top_n} Teams by Points")
    fig.savefig(config.FIGURES_DIR / "standings.png")
    plt.close(fig)


def plot_home_ice(home_ice: pd.DataFrame) -> None:
    """Bar chart of home-win percentage by season vs the 50% line."""
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.bar(home_ice["season"].astype(str), home_ice["home_win_pct"], color=_ACCENT)
    ax.axhline(50, color="black", linestyle="--", linewidth=1, label="Coin flip")
    ax.set_ylabel("Home win %")
    ax.set_title("Home-Ice Advantage by Season")
    ax.legend()
    fig.savefig(config.FIGURES_DIR / "home_ice_advantage.png")
    plt.close(fig)


def plot_roc(results: dict) -> None:
    """Overlay ROC curves for every fitted model."""
    _, x_test, _, y_test, _, _ = _split_cache["value"]
    fig, ax = plt.subplots(figsize=(6, 6))
    for name, result in results.items():
        if result.estimator is None:
            continue
        fpr, tpr = model_mod.roc_points(y_test, result.test_probabilities)
        ax.plot(fpr, tpr, label=f"{name} (AUC={result.metrics['roc_auc']:.3f})")
    ax.plot([0, 1], [0, 1], "k--", linewidth=1, label="Random")
    ax.set_xlabel("False positive rate")
    ax.set_ylabel("True positive rate")
    ax.set_title("ROC Curves: Home-Win Prediction")
    ax.legend(loc="lower right")
    fig.savefig(config.FIGURES_DIR / "roc_curves.png")
    plt.close(fig)


def plot_calibration(results: dict) -> None:
    """Reliability diagram for the best model."""
    _, _, _, y_test, _, _ = _split_cache["value"]
    best = model_mod.best_model(results)
    prob_true, prob_pred = calibration_curve(y_test, best.test_probabilities, n_bins=8)
    fig, ax = plt.subplots(figsize=(6, 6))
    ax.plot(prob_pred, prob_true, "o-", color=_ACCENT, label=best.name)
    ax.plot([0, 1], [0, 1], "k--", linewidth=1, label="Perfectly calibrated")
    ax.set_xlabel("Predicted probability")
    ax.set_ylabel("Observed frequency")
    ax.set_title("Calibration (Reliability) Curve")
    ax.legend(loc="upper left")
    fig.savefig(config.FIGURES_DIR / "calibration.png")
    plt.close(fig)


def plot_feature_importance(results: dict) -> None:
    """Bar chart of standardised logistic-regression coefficients."""
    lr = results.get("Logistic Regression")
    if lr is None or lr.estimator is None:
        return
    coefs = model_mod.logistic_coefficients(lr)
    ordered = sorted(coefs.items(), key=lambda kv: abs(kv[1]))
    labels = [k.replace("diff_", "").replace("_", " ") for k, _ in ordered]
    values = [v for _, v in ordered]
    colors = [_ACCENT if v >= 0 else "#1f3a5f" for v in values]
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.barh(labels, values, color=colors)
    ax.axvline(0, color="black", linewidth=0.8)
    ax.set_xlabel("Standardised coefficient (log-odds of home win)")
    ax.set_title("Which Pre-Game Signals Predict a Home Win?")
    fig.savefig(config.FIGURES_DIR / "feature_importance.png")
    plt.close(fig)


# Cache the train/test split so figure functions reuse the exact same data.
_split_cache: dict[str, tuple] = {"value": ()}


def cache_split(features_df) -> None:
    """Store the canonical split used across figures."""
    _split_cache["value"] = feat.time_based_split(features_df)


def generate_all(standings, home_ice, results, features_df) -> list[str]:
    """Produce every figure and return the saved file paths."""
    config.ensure_dirs()
    cache_split(features_df)
    plot_standings(standings)
    plot_home_ice(home_ice)
    plot_roc(results)
    plot_calibration(results)
    plot_feature_importance(results)
    return [str(p) for p in sorted(config.FIGURES_DIR.glob("*.png"))]
