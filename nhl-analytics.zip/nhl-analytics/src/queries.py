"""Named-query loader.

Parses ``sql/analytics_queries.sql`` into a dictionary keyed by the
``-- name: <key>`` markers, so analytical queries live in version-controlled
``.sql`` files (reviewable, reusable) rather than as strings scattered through
Python. This is the pattern many data teams standardise on.
"""

from __future__ import annotations

import re

import pandas as pd

from . import config, database

_NAME_MARKER = re.compile(r"^--\s*name:\s*(\w+)\s*$", re.MULTILINE)


def load_named_queries() -> dict[str, str]:
    """Split the analytics SQL file into ``{name: query}`` pairs."""
    text = (config.SQL_DIR / "analytics_queries.sql").read_text(encoding="utf-8")
    matches = list(_NAME_MARKER.finditer(text))
    queries: dict[str, str] = {}
    for index, match in enumerate(matches):
        name = match.group(1)
        start = match.end()
        end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
        body = text[start:end].strip()
        # Drop trailing comment lines that belong to the next query's header.
        queries[name] = body
    return queries


def run(name: str) -> pd.DataFrame:
    """Execute a named query and return the result."""
    queries = load_named_queries()
    if name not in queries:
        raise KeyError(f"No query named {name!r}. Available: {sorted(queries)}")
    return database.read_query(queries[name])


def run_all() -> dict[str, pd.DataFrame]:
    """Execute every named query and return the results."""
    return {name: database.read_query(query) for name, query in load_named_queries().items()}
