"""Data ingestion for the NHL analytics pipeline.

Two sources are supported:

* ``synthetic`` (default) - generates a reproducible, statistically realistic
  season from a latent team-strength model. This makes the repository fully
  self-contained: anyone (including CI) can run the entire pipeline with no
  network access or API keys.
* ``api`` - pulls real game data from the NHL's public stats API. The code is
  provided so the project runs on live data when executed locally with network
  access; it is not exercised in CI.

Both sources emit the same three tidy tables: ``teams``, ``games`` and
``team_game_stats``.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from . import config

# The 32 NHL franchises with conference/division metadata. Used by both the
# synthetic generator and as the canonical team dimension table.
TEAMS = [
    ("ANA", "Anaheim Ducks", "Western", "Pacific"),
    ("ARI", "Arizona Coyotes", "Western", "Central"),
    ("BOS", "Boston Bruins", "Eastern", "Atlantic"),
    ("BUF", "Buffalo Sabres", "Eastern", "Atlantic"),
    ("CGY", "Calgary Flames", "Western", "Pacific"),
    ("CAR", "Carolina Hurricanes", "Eastern", "Metropolitan"),
    ("CHI", "Chicago Blackhawks", "Western", "Central"),
    ("COL", "Colorado Avalanche", "Western", "Central"),
    ("CBJ", "Columbus Blue Jackets", "Eastern", "Metropolitan"),
    ("DAL", "Dallas Stars", "Western", "Central"),
    ("DET", "Detroit Red Wings", "Eastern", "Atlantic"),
    ("EDM", "Edmonton Oilers", "Western", "Pacific"),
    ("FLA", "Florida Panthers", "Eastern", "Atlantic"),
    ("LAK", "Los Angeles Kings", "Western", "Pacific"),
    ("MIN", "Minnesota Wild", "Western", "Central"),
    ("MTL", "Montreal Canadiens", "Eastern", "Atlantic"),
    ("NSH", "Nashville Predators", "Western", "Central"),
    ("NJD", "New Jersey Devils", "Eastern", "Metropolitan"),
    ("NYI", "New York Islanders", "Eastern", "Metropolitan"),
    ("NYR", "New York Rangers", "Eastern", "Metropolitan"),
    ("OTT", "Ottawa Senators", "Eastern", "Atlantic"),
    ("PHI", "Philadelphia Flyers", "Eastern", "Metropolitan"),
    ("PIT", "Pittsburgh Penguins", "Eastern", "Metropolitan"),
    ("SJS", "San Jose Sharks", "Western", "Pacific"),
    ("SEA", "Seattle Kraken", "Western", "Pacific"),
    ("STL", "St. Louis Blues", "Western", "Central"),
    ("TBL", "Tampa Bay Lightning", "Eastern", "Atlantic"),
    ("TOR", "Toronto Maple Leafs", "Eastern", "Atlantic"),
    ("VAN", "Vancouver Canucks", "Western", "Pacific"),
    ("VGK", "Vegas Golden Knights", "Western", "Pacific"),
    ("WSH", "Washington Capitals", "Eastern", "Metropolitan"),
    ("WPG", "Winnipeg Jets", "Western", "Central"),
]


def build_teams_frame() -> pd.DataFrame:
    """Return the canonical teams dimension table."""
    records = [
        {
            "team_id": index + 1,
            "abbrev": abbrev,
            "name": name,
            "conference": conference,
            "division": division,
        }
        for index, (abbrev, name, conference, division) in enumerate(TEAMS)
    ]
    return pd.DataFrame.from_records(records)


def _round_robin_schedule(team_ids: list[int], rng: np.random.Generator) -> list[tuple[int, int]]:
    """Generate a balanced home/away schedule using the circle method.

    Each pairing is played twice so home-ice advantage is symmetric across the
    season. The ordering is shuffled so game dates are not perfectly regular.
    """
    pairings: list[tuple[int, int]] = []
    for i, home in enumerate(team_ids):
        for away in team_ids[i + 1 :]:
            pairings.append((home, away))
            pairings.append((away, home))
    rng.shuffle(pairings)
    return pairings


def _simulate_box_stats(
    strength_diff: float,
    is_home: bool,
    rng: np.random.Generator,
) -> dict[str, float]:
    """Draw a plausible single-game box score for one team.

    Stats are centered on league-typical values and nudged by the strength
    differential so that better teams out-shoot and out-possess opponents.
    This gives the downstream SQL and features something real to recover.
    """
    edge = strength_diff + (0.15 if is_home else -0.15)
    shots = int(np.clip(rng.normal(30 + 6 * edge, 5), 15, 55))
    hits = int(np.clip(rng.normal(22, 6), 5, 50))
    blocks = int(np.clip(rng.normal(14, 4), 2, 35))
    pp_opportunities = int(np.clip(rng.poisson(3.2), 0, 9))
    pp_goals = int(np.clip(rng.binomial(pp_opportunities, 0.21), 0, pp_opportunities))
    faceoff_win_pct = float(np.clip(rng.normal(50 + 4 * edge, 5), 30, 70))
    giveaways = int(np.clip(rng.normal(9, 3), 1, 25))
    takeaways = int(np.clip(rng.normal(7 + 2 * edge, 3), 1, 25))
    return {
        "shots": shots,
        "hits": hits,
        "blocks": blocks,
        "pp_opportunities": pp_opportunities,
        "pp_goals": pp_goals,
        "faceoff_win_pct": round(faceoff_win_pct, 1),
        "giveaways": giveaways,
        "takeaways": takeaways,
    }


def generate_synthetic(
    seasons: list[str] | None = None,
    seed: int = config.RANDOM_STATE,
) -> dict[str, pd.DataFrame]:
    """Generate a reproducible, learnable synthetic dataset.

    A latent strength is assigned to each team per season. Game outcomes are
    drawn from a Poisson goal model whose rate depends on the strength
    differential plus a home-ice advantage term, so recent-form features carry
    genuine (but noisy) predictive signal - mirroring how hard real NHL game
    prediction actually is.
    """
    seasons = seasons or config.SYNTHETIC_SEASONS
    rng = np.random.default_rng(seed)

    teams = build_teams_frame()
    team_ids = teams["team_id"].tolist()

    home_ice_advantage = 0.18
    games_records: list[dict] = []
    stats_records: list[dict] = []
    game_id = 1

    for season in seasons:
        # Latent per-team strength: a wider spread means the talent gap between
        # contenders and bottom feeders is larger, so recent form carries more
        # (still noisy) signal - matching strong real-world form-based models.
        strengths = {tid: rng.normal(0, 0.45) for tid in team_ids}
        schedule = _round_robin_schedule(team_ids, rng)

        season_start = pd.Timestamp(f"{season[:4]}-10-10")
        for offset, (home_id, away_id) in enumerate(schedule):
            game_date = season_start + pd.Timedelta(days=offset // 8)
            diff = strengths[home_id] - strengths[away_id] + home_ice_advantage

            # Expected goals scale with the strength differential.
            home_lambda = float(np.clip(2.9 + 1.05 * diff, 1.2, 5.2))
            away_lambda = float(np.clip(2.9 - 1.05 * diff, 1.2, 5.2))
            home_goals = int(rng.poisson(home_lambda))
            away_goals = int(rng.poisson(away_lambda))
            if home_goals == away_goals:  # resolve ties via a shootout coin flip
                if rng.random() < 1 / (1 + np.exp(-diff)):
                    home_goals += 1
                else:
                    away_goals += 1

            games_records.append(
                {
                    "game_id": game_id,
                    "season": season,
                    "game_date": game_date.strftime("%Y-%m-%d"),
                    "home_team_id": home_id,
                    "away_team_id": away_id,
                    "home_goals": home_goals,
                    "away_goals": away_goals,
                    "home_win": int(home_goals > away_goals),
                }
            )

            home_stats = _simulate_box_stats(strengths[home_id] - strengths[away_id], True, rng)
            home_stats.update({"game_id": game_id, "team_id": home_id, "is_home": 1, "goals": home_goals})
            away_stats = _simulate_box_stats(strengths[away_id] - strengths[home_id], False, rng)
            away_stats.update({"game_id": game_id, "team_id": away_id, "is_home": 0, "goals": away_goals})
            stats_records.append(home_stats)
            stats_records.append(away_stats)
            game_id += 1

    games = pd.DataFrame.from_records(games_records).sort_values("game_date").reset_index(drop=True)
    team_game_stats = pd.DataFrame.from_records(stats_records)
    return {"teams": teams, "games": games, "team_game_stats": team_game_stats}


# ---------------------------------------------------------------------------
# Live NHL API path. Runnable locally with network access; not used by CI.
# ---------------------------------------------------------------------------
def fetch_from_api(seasons: list[str] | None = None) -> dict[str, pd.DataFrame]:
    """Pull real schedule and box-score data from the NHL public API.

    Requires network access. Mirrors the synthetic output schema so the rest
    of the pipeline is source-agnostic.
    """
    import requests  # imported lazily so the synthetic path needs no extra deps

    seasons = seasons or config.DEFAULT_SEASONS
    teams = build_teams_frame()
    abbrev_to_id = dict(zip(teams["abbrev"], teams["team_id"]))

    games_records: list[dict] = []
    stats_records: list[dict] = []
    seen_games: set[int] = set()

    session = requests.Session()
    for season in seasons:
        for abbrev in teams["abbrev"]:
            url = f"{config.NHL_API_BASE}/club-schedule-season/{abbrev}/{season}"
            response = session.get(url, timeout=30)
            response.raise_for_status()
            for game in response.json().get("games", []):
                game_pk = game["id"]
                if game_pk in seen_games or game.get("gameType") != 2:
                    continue  # gameType 2 == regular season
                seen_games.add(game_pk)

                home = game["homeTeam"]
                away = game["awayTeam"]
                home_id = abbrev_to_id.get(home["abbrev"])
                away_id = abbrev_to_id.get(away["abbrev"])
                if home_id is None or away_id is None:
                    continue
                home_goals = home.get("score")
                away_goals = away.get("score")
                if home_goals is None or away_goals is None:
                    continue  # game not played yet

                games_records.append(
                    {
                        "game_id": game_pk,
                        "season": season,
                        "game_date": game["gameDate"],
                        "home_team_id": home_id,
                        "away_team_id": away_id,
                        "home_goals": home_goals,
                        "away_goals": away_goals,
                        "home_win": int(home_goals > away_goals),
                    }
                )
                stats_records.extend(_fetch_boxscore(session, game_pk, home_id, away_id))

    games = pd.DataFrame.from_records(games_records).sort_values("game_date").reset_index(drop=True)
    team_game_stats = pd.DataFrame.from_records(stats_records)
    return {"teams": teams, "games": games, "team_game_stats": team_game_stats}


def _fetch_boxscore(session, game_pk: int, home_id: int, away_id: int) -> list[dict]:
    """Fetch and flatten team box-score stats for a single game."""
    url = f"{config.NHL_API_BASE}/gamecenter/{game_pk}/boxscore"
    response = session.get(url, timeout=30)
    response.raise_for_status()
    payload = response.json()
    rows: list[dict] = []
    for side, team_id in (("homeTeam", home_id), ("awayTeam", away_id)):
        team = payload.get(side, {})
        rows.append(
            {
                "game_id": game_pk,
                "team_id": team_id,
                "is_home": int(side == "homeTeam"),
                "goals": team.get("score", 0),
                "shots": team.get("sog", 0),
                "hits": team.get("hits", 0),
                "blocks": team.get("blocks", 0),
                "pp_opportunities": 0,
                "pp_goals": 0,
                "faceoff_win_pct": float(team.get("faceoffWinningPctg", 0.5)) * 100,
                "giveaways": team.get("giveaways", 0),
                "takeaways": team.get("takeaways", 0),
            }
        )
    return rows


def load_data(source: str = "synthetic", seasons: list[str] | None = None) -> dict[str, pd.DataFrame]:
    """Dispatch to the requested data source."""
    if source == "api":
        return fetch_from_api(seasons)
    if source == "synthetic":
        return generate_synthetic(seasons)
    raise ValueError(f"Unknown source: {source!r}. Use 'synthetic' or 'api'.")
