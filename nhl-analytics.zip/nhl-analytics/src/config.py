"""Central configuration for the NHL analytics pipeline.

Keeping paths, constants, and tunable parameters in one place makes the
pipeline reproducible and easy to point at a different season or database.
"""

from __future__ import annotations

from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data"
REPORTS_DIR = PROJECT_ROOT / "reports"
FIGURES_DIR = REPORTS_DIR / "figures"
SQL_DIR = PROJECT_ROOT / "sql"

DB_PATH = DATA_DIR / "nhl.db"

# NHL public stats API (used by ingest.py when --source api is selected).
NHL_API_BASE = "https://api-web.nhle.com/v1"

# Seasons are encoded by the NHL as the start and end year, e.g. 2023-24.
DEFAULT_SEASONS = ["20222023", "20232024"]

# Rolling-window length (in games) used to build recent-form features.
FORM_WINDOW = 10

# Fraction of the most recent games held out for the test set. We split by
# time rather than randomly so the evaluation mimics forecasting future games.
TEST_FRACTION = 0.20

RANDOM_STATE = 42

# Reproducible synthetic-data settings (used when --source synthetic).
SYNTHETIC_SEASONS = ["20222023", "20232024"]
GAMES_PER_TEAM_PER_SEASON = 82


def ensure_dirs() -> None:
    """Create the output directories the pipeline writes to."""
    for directory in (DATA_DIR, REPORTS_DIR, FIGURES_DIR):
        directory.mkdir(parents=True, exist_ok=True)
