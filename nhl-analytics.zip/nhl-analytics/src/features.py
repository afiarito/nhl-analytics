"""Feature engineering for game-outcome prediction.

The cardinal rule here is *no leakage*: every feature describing a game is
built only from games that occurred strictly before it. We process games in
chronological order and maintain running per-team histories, so the model is
always asked to forecast using only information that would have been available
at puck drop. This mirrors how the model would be used in production and is the
difference between an honest AUC and an inflated one.
"""

from __future__ import annotations

from collections import defaultdict, deque

import numpy as np
import pandas as pd

from . import config


def _form_dict() -> dict:
    """Per-team rolling state used while walking the schedule."""
    return {
        "results": deque(maxlen=config.FORM_WINDOW),
        "goals_for": deque(maxlen=config.FORM_WINDOW),
        "goals_against": deque(maxlen=config.FORM_WINDOW),
        "season_wins": 0,
        "season_games": 0,
        "last_game_date": None,
    }


def _summarise(state: dict, game_date: pd.Timestamp) -> dict[str, float]:
    """Turn a team's accumulated history into model-ready numbers."""
    n = len(state["results"])
    rolling_win_pct = float(np.mean(state["results"])) if n else 0.5
    rolling_gf = float(np.mean(state["goals_for"])) if n else 2.9
    rolling_ga = float(np.mean(state["goals_against"])) if n else 2.9
    season_win_pct = (
        state["season_wins"] / state["season_games"] if state["season_games"] else 0.5
    )
    if state["last_game_date"] is None:
        rest_days = 3.0
    else:
        rest_days = float((game_date - state["last_game_date"]).days)
    return {
        "rolling_win_pct": rolling_win_pct,
        "rolling_goals_for": rolling_gf,
        "rolling_goals_against": rolling_ga,
        "rolling_goal_diff": rolling_gf - rolling_ga,
        "season_win_pct": season_win_pct,
        "games_played": float(state["season_games"]),
        "rest_days": float(np.clip(rest_days, 0, 7)),
    }


def build_features(games: pd.DataFrame) -> pd.DataFrame:
    """Construct a model-ready feature matrix, one row per game.

    Features are the *difference* between the home and away teams' pre-game
    form (home minus away), which is a compact, well-scaled representation for
    a win/loss classifier.
    """
    games = games.copy()
    games["game_date"] = pd.to_datetime(games["game_date"])
    games = games.sort_values(["game_date", "game_id"]).reset_index(drop=True)

    states: dict[tuple[str, int], dict] = defaultdict(_form_dict)
    rows: list[dict] = []

    for _, game in games.iterrows():
        season = game["season"]
        home_key = (season, game["home_team_id"])
        away_key = (season, game["away_team_id"])
        home_state = states[home_key]
        away_state = states[away_key]

        home_form = _summarise(home_state, game["game_date"])
        away_form = _summarise(away_state, game["game_date"])

        feature_row = {
            "game_id": game["game_id"],
            "season": season,
            "game_date": game["game_date"],
            "home_win": int(game["home_win"]),
            "diff_rolling_win_pct": home_form["rolling_win_pct"] - away_form["rolling_win_pct"],
            "diff_rolling_goal_diff": home_form["rolling_goal_diff"] - away_form["rolling_goal_diff"],
            "diff_rolling_goals_for": home_form["rolling_goals_for"] - away_form["rolling_goals_for"],
            "diff_rolling_goals_against": home_form["rolling_goals_against"]
            - away_form["rolling_goals_against"],
            "diff_season_win_pct": home_form["season_win_pct"] - away_form["season_win_pct"],
            "diff_rest_days": home_form["rest_days"] - away_form["rest_days"],
            "home_games_played": home_form["games_played"],
            "away_games_played": away_form["games_played"],
        }
        rows.append(feature_row)

        # --- Update histories AFTER recording the row (no leakage). ---
        home_won = int(game["home_win"])
        home_state["results"].append(home_won)
        away_state["results"].append(1 - home_won)
        home_state["goals_for"].append(game["home_goals"])
        home_state["goals_against"].append(game["away_goals"])
        away_state["goals_for"].append(game["away_goals"])
        away_state["goals_against"].append(game["home_goals"])
        home_state["season_wins"] += home_won
        away_state["season_wins"] += 1 - home_won
        home_state["season_games"] += 1
        away_state["season_games"] += 1
        home_state["last_game_date"] = game["game_date"]
        away_state["last_game_date"] = game["game_date"]

    features = pd.DataFrame(rows)
    # Drop the earliest games where neither team has any history to learn from.
    warmup = config.FORM_WINDOW // 2
    features = features[
        (features["home_games_played"] >= warmup) & (features["away_games_played"] >= warmup)
    ].reset_index(drop=True)
    return features


FEATURE_COLUMNS = [
    "diff_rolling_win_pct",
    "diff_rolling_goal_diff",
    "diff_rolling_goals_for",
    "diff_rolling_goals_against",
    "diff_season_win_pct",
    "diff_rest_days",
]


def time_based_split(features: pd.DataFrame, test_fraction: float = config.TEST_FRACTION):
    """Split chronologically so the test set is the most recent games.

    A random split would let the model peek at the future; a temporal split is
    the honest evaluation for a forecasting task.
    """
    features = features.sort_values(["game_date", "game_id"]).reset_index(drop=True)
    cutoff = int(len(features) * (1 - test_fraction))
    train = features.iloc[:cutoff]
    test = features.iloc[cutoff:]
    x_train = train[FEATURE_COLUMNS].to_numpy()
    y_train = train["home_win"].to_numpy()
    x_test = test[FEATURE_COLUMNS].to_numpy()
    y_test = test["home_win"].to_numpy()
    return x_train, x_test, y_train, y_test, train, test
