"""Model training and evaluation for home-win prediction.

Two models are compared against a naive baseline:

* **Baseline** - always predict the home team wins (the majority class in
  hockey). Any model has to beat this to be worth anything.
* **Logistic Regression** - a calibrated, interpretable linear benchmark whose
  coefficients map directly to "which form signals matter".
* **Gradient Boosting** - a non-linear model to check whether interactions buy
  additional accuracy.

Evaluation uses time-series cross-validation on the training set plus a final
held-out (most-recent-games) test set, and reports ROC/AUC, accuracy, log loss,
and the Brier score (calibration). These were chosen because game prediction is
a probabilistic task: a well-calibrated 60% is more useful than an overconfident
but wrong 90%.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    brier_score_loss,
    log_loss,
    roc_auc_score,
    roc_curve,
)
from sklearn.model_selection import TimeSeriesSplit, cross_val_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from . import config, features as feat


@dataclass
class ModelResult:
    """Container for a single model's fitted estimator and metrics."""

    name: str
    estimator: object
    metrics: dict[str, float] = field(default_factory=dict)
    test_probabilities: np.ndarray = field(default_factory=lambda: np.array([]))


def _build_estimators() -> dict[str, Pipeline]:
    """Define the candidate models. Scaling matters for logistic regression."""
    return {
        "Logistic Regression": Pipeline(
            steps=[
                ("scaler", StandardScaler()),
                ("clf", LogisticRegression(max_iter=1000, random_state=config.RANDOM_STATE)),
            ]
        ),
        "Gradient Boosting": Pipeline(
            steps=[
                (
                    "clf",
                    GradientBoostingClassifier(
                        n_estimators=200,
                        max_depth=3,
                        learning_rate=0.05,
                        random_state=config.RANDOM_STATE,
                    ),
                )
            ]
        ),
    }


def _baseline_metrics(y_test: np.ndarray) -> dict[str, float]:
    """Metrics for the always-predict-home baseline."""
    home_rate = float(np.mean(y_test))
    predictions = np.ones_like(y_test)
    probabilities = np.full_like(y_test, home_rate, dtype=float)
    return {
        "accuracy": accuracy_score(y_test, predictions),
        "roc_auc": 0.5,  # a constant predictor has no ranking power
        "log_loss": log_loss(y_test, probabilities, labels=[0, 1]),
        "brier": brier_score_loss(y_test, probabilities),
    }


def train_and_evaluate(features_df) -> dict[str, ModelResult]:
    """Train every candidate model and return their evaluation results."""
    x_train, x_test, y_train, y_test, _, _ = feat.time_based_split(features_df)
    splitter = TimeSeriesSplit(n_splits=5)
    results: dict[str, ModelResult] = {}

    # Baseline is reported as a ModelResult with no estimator to fit.
    results["Baseline (home pick)"] = ModelResult(
        name="Baseline (home pick)",
        estimator=None,
        metrics=_baseline_metrics(y_test),
    )

    for name, estimator in _build_estimators().items():
        cv_auc = cross_val_score(
            estimator, x_train, y_train, cv=splitter, scoring="roc_auc"
        )
        estimator.fit(x_train, y_train)
        proba = estimator.predict_proba(x_test)[:, 1]
        predictions = (proba >= 0.5).astype(int)
        metrics = {
            "cv_auc_mean": float(np.mean(cv_auc)),
            "cv_auc_std": float(np.std(cv_auc)),
            "accuracy": accuracy_score(y_test, predictions),
            "roc_auc": roc_auc_score(y_test, proba),
            "log_loss": log_loss(y_test, proba, labels=[0, 1]),
            "brier": brier_score_loss(y_test, proba),
        }
        results[name] = ModelResult(
            name=name, estimator=estimator, metrics=metrics, test_probabilities=proba
        )

    return results


def logistic_coefficients(result: ModelResult) -> dict[str, float]:
    """Return feature coefficients from a fitted logistic-regression pipeline.

    Coefficients are on the standardised scale, so their magnitudes are
    directly comparable as feature-importance weights.
    """
    clf = result.estimator.named_steps["clf"]
    return dict(zip(feat.FEATURE_COLUMNS, clf.coef_[0]))


def best_model(results: dict[str, ModelResult]) -> ModelResult:
    """Pick the model with the highest held-out ROC/AUC (excluding baseline)."""
    candidates = [r for r in results.values() if r.estimator is not None]
    return max(candidates, key=lambda r: r.metrics["roc_auc"])


def roc_points(y_test: np.ndarray, proba: np.ndarray):
    """Return false-positive and true-positive rates for an ROC plot."""
    fpr, tpr, _ = roc_curve(y_test, proba)
    return fpr, tpr
