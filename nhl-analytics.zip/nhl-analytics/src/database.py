"""SQLite persistence layer.

Loads the tidy DataFrames produced by :mod:`src.ingest` into a SQLite database
defined by ``sql/schema.sql``. SQLite is used deliberately: it ships with
Python, needs no server, and commits cleanly to the repository, while still
supporting the CTEs and window functions the analytical queries rely on.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

import pandas as pd

from . import config


def apply_schema(connection: sqlite3.Connection) -> None:
    """Execute the DDL in ``sql/schema.sql`` against an open connection."""
    schema_sql = (config.SQL_DIR / "schema.sql").read_text(encoding="utf-8")
    connection.executescript(schema_sql)


def build_database(
    tables: dict[str, pd.DataFrame],
    db_path: Path | None = None,
) -> Path:
    """Create the database, apply the schema, and load each table.

    Returns the path to the database file so callers can chain operations.
    """
    db_path = db_path or config.DB_PATH
    db_path.parent.mkdir(parents=True, exist_ok=True)
    if db_path.exists():
        db_path.unlink()

    with sqlite3.connect(db_path) as connection:
        connection.execute("PRAGMA foreign_keys = ON;")
        apply_schema(connection)
        for table_name in ("teams", "games", "team_game_stats"):
            tables[table_name].to_sql(table_name, connection, if_exists="append", index=False)
        connection.commit()
    return db_path


def get_connection(db_path: Path | None = None) -> sqlite3.Connection:
    """Open a connection to the analytics database with row access by name."""
    db_path = db_path or config.DB_PATH
    connection = sqlite3.connect(db_path)
    connection.row_factory = sqlite3.Row
    return connection


def read_query(query: str, db_path: Path | None = None) -> pd.DataFrame:
    """Run an arbitrary SQL string and return the result as a DataFrame."""
    with get_connection(db_path) as connection:
        return pd.read_sql_query(query, connection)
