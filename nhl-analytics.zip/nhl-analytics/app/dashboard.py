"""Interactive Streamlit dashboard for the NHL analytics pipeline.

Run with::

    streamlit run app/dashboard.py

The dashboard builds (or reuses) the SQLite database on first load, then lets
the user explore standings, home-ice advantage, team efficiency, and a live
win-probability calculator backed by the trained model.
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import streamlit as st

sys.path.append(str(Path(__file__).resolve().parents[1]))

from src import config, database, features as feat, ingest, model as model_mod, queries

st.set_page_config(page_title="NHL Analytics", page_icon="🏒", layout="wide")

ACCENT = "#C8102E"


@st.cache_resource(show_spinner="Building dataset and training model...")
def bootstrap():
    """Generate data, build the database, and train the model once per session."""
    config.ensure_dirs()
    tables = ingest.load_data(source="synthetic")
    database.build_database(tables)
    features_df = feat.build_features(tables["games"])
    results = model_mod.train_and_evaluate(features_df)
    return tables, results


tables, results = bootstrap()
champion = model_mod.best_model(results)

st.title("🏒 NHL Game Analytics & Win-Probability Model")
st.caption(
    "End-to-end pipeline: SQLite analytics, leakage-aware feature engineering, "
    "and a calibrated win-probability model. Synthetic season shown by default."
)

col1, col2, col3, col4 = st.columns(4)
col1.metric("Games analysed", f"{len(tables['games']):,}")
col2.metric("Best model", champion.name)
col3.metric("Test ROC-AUC", f"{champion.metrics['roc_auc']:.3f}")
col4.metric("Test accuracy", f"{champion.metrics['accuracy']:.3f}")

tab_standings, tab_efficiency, tab_model, tab_predict = st.tabs(
    ["Standings", "Team efficiency", "Model performance", "Win-probability calculator"]
)

with tab_standings:
    st.subheader("League standings (computed in SQL)")
    standings = queries.run("standings")
    st.dataframe(standings, use_container_width=True, hide_index=True)
    st.subheader("Home-ice advantage")
    home_ice = queries.run("home_ice_advantage")
    st.bar_chart(home_ice.set_index("season")["home_win_pct"])

with tab_efficiency:
    st.subheader("Possession & special-teams efficiency")
    efficiency = queries.run("team_efficiency")
    st.dataframe(efficiency, use_container_width=True, hide_index=True)

with tab_model:
    st.subheader("Model comparison")
    rows = []
    for name, res in results.items():
        m = res.metrics
        rows.append(
            {
                "Model": name,
                "Accuracy": round(m["accuracy"], 3),
                "ROC-AUC": round(m["roc_auc"], 3),
                "Log loss": round(m["log_loss"], 3),
                "Brier": round(m["brier"], 3),
            }
        )
    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
    st.caption(
        "Baseline = always predict the home team. AUC and Brier score reveal "
        "ranking power and calibration that raw accuracy hides when one class "
        "dominates."
    )
    coefs = model_mod.logistic_coefficients(results["Logistic Regression"])
    coef_df = pd.DataFrame(
        {"feature": list(coefs), "coefficient": list(coefs.values())}
    ).sort_values("coefficient")
    st.subheader("What drives a home win? (logistic coefficients)")
    st.bar_chart(coef_df.set_index("feature")["coefficient"])

with tab_predict:
    st.subheader("Estimate a home-team win probability")
    st.caption("Move the sliders to describe the two teams' recent form, then read the model's probability.")
    c1, c2 = st.columns(2)
    with c1:
        home_form = st.slider("Home rolling win % (last 10)", 0.0, 1.0, 0.6, 0.05)
        home_gd = st.slider("Home rolling goal diff/game", -2.0, 2.0, 0.4, 0.1)
        home_season = st.slider("Home season win %", 0.0, 1.0, 0.58, 0.02)
    with c2:
        away_form = st.slider("Away rolling win % (last 10)", 0.0, 1.0, 0.45, 0.05)
        away_gd = st.slider("Away rolling goal diff/game", -2.0, 2.0, -0.2, 0.1)
        away_season = st.slider("Away season win %", 0.0, 1.0, 0.48, 0.02)
    rest_diff = st.slider("Home rest-day advantage", -3.0, 3.0, 0.0, 1.0)

    feature_vector = np.array(
        [[
            home_form - away_form,
            home_gd - away_gd,
            (home_gd + 2.9) - (away_gd + 2.9),  # rolling goals-for proxy
            (2.9 - home_gd) - (2.9 - away_gd),  # rolling goals-against proxy
            home_season - away_season,
            rest_diff,
        ]]
    )
    proba = champion.estimator.predict_proba(feature_vector)[0, 1]
    st.metric("Home-team win probability", f"{proba * 100:.1f}%")
    st.progress(float(proba))
