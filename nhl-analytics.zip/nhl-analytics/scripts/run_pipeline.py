"""Run the full NHL analytics pipeline end to end.

Usage::

    python -m scripts.run_pipeline                 # synthetic data (default)
    python -m scripts.run_pipeline --source api    # live NHL API (needs network)

Steps: ingest -> load to SQLite -> run analytical SQL -> engineer features ->
train & evaluate models -> render figures. Prints a concise report to stdout.
"""

from __future__ import annotations

import argparse

from src import config, database, features as feat, ingest, model as model_mod
from src import queries, visualize


def _print_header(title: str) -> None:
    print(f"\n{'=' * 64}\n{title}\n{'=' * 64}")


def main() -> None:
    parser = argparse.ArgumentParser(description="NHL analytics pipeline")
    parser.add_argument(
        "--source",
        choices=["synthetic", "api"],
        default="synthetic",
        help="Data source (default: synthetic, fully offline)",
    )
    args = parser.parse_args()
    config.ensure_dirs()

    _print_header(f"1. Ingesting data (source = {args.source})")
    tables = ingest.load_data(source=args.source)
    print(f"   teams: {len(tables['teams'])}  games: {len(tables['games'])}  "
          f"box-score rows: {len(tables['team_game_stats'])}")

    _print_header("2. Building SQLite database")
    db_path = database.build_database(tables)
    print(f"   wrote {db_path}")

    _print_header("3. Analytical SQL")
    standings = queries.run("standings")
    home_ice = queries.run("home_ice_advantage")
    print("   League standings (top 5):")
    print(standings[["abbrev", "wins", "losses", "points", "goal_differential"]].head().to_string(index=False))
    print("\n   Home-ice advantage by season:")
    print(home_ice[["season", "games", "home_win_pct"]].to_string(index=False))

    _print_header("4. Feature engineering (leakage-aware)")
    features_df = feat.build_features(tables["games"])
    print(f"   modelling rows: {len(features_df)}  features: {len(feat.FEATURE_COLUMNS)}")

    _print_header("5. Model training & evaluation")
    results = model_mod.train_and_evaluate(features_df)
    print(f"   {'model':<24}{'acc':>7}{'AUC':>8}{'logloss':>10}{'brier':>8}")
    for name, res in results.items():
        m = res.metrics
        print(f"   {name:<24}{m['accuracy']:>7.3f}{m['roc_auc']:>8.3f}"
              f"{m['log_loss']:>10.3f}{m['brier']:>8.3f}")
    champion = model_mod.best_model(results)
    print(f"\n   Best model: {champion.name} (test AUC = {champion.metrics['roc_auc']:.3f})")

    _print_header("6. Rendering figures")
    paths = visualize.generate_all(standings, home_ice, results, features_df)
    for path in paths:
        print(f"   {path}")

    _print_header("Pipeline complete")


if __name__ == "__main__":
    main()
