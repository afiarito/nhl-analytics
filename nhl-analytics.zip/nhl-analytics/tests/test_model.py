"""Tests for the SQL layer and model training."""

from __future__ import annotations

import tempfile
from pathlib import Path

from src import database, features as feat, ingest, model as model_mod, queries


def _temp_db():
    data = ingest.generate_synthetic(seasons=["20232024"], seed=5)
    tmp = Path(tempfile.mkdtemp()) / "test.db"
    database.build_database(data, db_path=tmp)
    return data, tmp


def test_named_queries_parse():
    names = set(queries.load_named_queries())
    assert {"standings", "home_ice_advantage", "team_efficiency", "rolling_form"} <= names


def test_standings_sum_to_total_games():
    data, tmp = _temp_db()
    standings = database.read_query(queries.load_named_queries()["standings"], db_path=tmp)
    # Every game contributes exactly one win across the league.
    assert standings["wins"].sum() == len(data["games"])
    assert (standings["win_pct"].between(0, 1)).all()


def test_window_function_query_runs():
    _, tmp = _temp_db()
    rolling = database.read_query(queries.load_named_queries()["rolling_form"], db_path=tmp)
    assert "rolling_win_pct_10" in rolling.columns
    assert rolling["rolling_win_pct_10"].between(0, 1).all()


def test_model_beats_baseline():
    data = ingest.generate_synthetic(seasons=["20222023", "20232024"], seed=9)
    features = feat.build_features(data["games"])
    results = model_mod.train_and_evaluate(features)
    best = model_mod.best_model(results)
    baseline = results["Baseline (home pick)"]
    # A useful model must rank better than chance and beat baseline accuracy.
    assert best.metrics["roc_auc"] > 0.55
    assert best.metrics["accuracy"] >= baseline.metrics["accuracy"]


def test_logistic_coefficients_returned():
    data = ingest.generate_synthetic(seasons=["20232024"], seed=2)
    features = feat.build_features(data["games"])
    results = model_mod.train_and_evaluate(features)
    coefs = model_mod.logistic_coefficients(results["Logistic Regression"])
    assert set(coefs) == set(feat.FEATURE_COLUMNS)
