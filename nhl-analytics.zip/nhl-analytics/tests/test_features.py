"""Tests for feature engineering, focused on the no-leakage guarantee."""

from __future__ import annotations

import numpy as np
import pandas as pd

from src import features as feat, ingest


def _toy_games() -> pd.DataFrame:
    return ingest.generate_synthetic(seasons=["20232024"], seed=11)["games"]


def test_features_have_expected_columns():
    features = feat.build_features(_toy_games())
    for column in feat.FEATURE_COLUMNS:
        assert column in features.columns
    assert "home_win" in features.columns


def test_first_recorded_game_has_no_prior_form():
    """A team with no history must receive neutral priors (0.5 win pct, league
    average goals), proving features never peek at the game being predicted.
    We exercise the per-team summary directly with an empty state."""
    state = feat._form_dict()
    summary = feat._summarise(state, pd.Timestamp("2023-10-10"))
    assert np.isclose(summary["rolling_win_pct"], 0.5)
    assert np.isclose(summary["season_win_pct"], 0.5)
    assert np.isclose(summary["rolling_goal_diff"], 0.0)
    assert summary["games_played"] == 0.0


def test_time_split_is_chronological():
    features = feat.build_features(_toy_games())
    _, _, _, _, train, test = feat.time_based_split(features)
    assert train["game_date"].max() <= test["game_date"].min()
    assert len(test) > 0 and len(train) > 0


def test_no_target_leakage_into_features():
    """No feature column may be the target or a transform of same-game goals."""
    features = feat.build_features(_toy_games())
    forbidden = {"home_goals", "away_goals", "goals"}
    assert forbidden.isdisjoint(set(feat.FEATURE_COLUMNS))
    assert forbidden.isdisjoint(set(features.columns) - {"home_win"})
