"""Tests for data ingestion and the synthetic generator."""

from __future__ import annotations

import pandas as pd

from src import ingest


def test_teams_frame_has_32_unique_teams():
    teams = ingest.build_teams_frame()
    assert len(teams) == 32
    assert teams["team_id"].is_unique
    assert teams["abbrev"].is_unique
    assert set(teams["conference"]) == {"Eastern", "Western"}


def test_synthetic_is_reproducible():
    first = ingest.generate_synthetic(seasons=["20232024"], seed=7)
    second = ingest.generate_synthetic(seasons=["20232024"], seed=7)
    pd.testing.assert_frame_equal(first["games"], second["games"])


def test_synthetic_schema_and_consistency():
    data = ingest.generate_synthetic(seasons=["20232024"], seed=1)
    games = data["games"]
    stats = data["team_game_stats"]

    # home_win must agree with the goal totals.
    assert (games["home_win"] == (games["home_goals"] > games["away_goals"]).astype(int)).all()
    # No ties survive (every game has a winner).
    assert (games["home_goals"] != games["away_goals"]).all()
    # Exactly two box-score rows per game.
    assert len(stats) == 2 * len(games)
    # Box-score goals reconcile with the games table.
    merged = stats.merge(games[["game_id", "home_team_id", "home_goals", "away_goals"]], on="game_id")
    home_rows = merged[merged["team_id"] == merged["home_team_id"]]
    assert (home_rows["goals"] == home_rows["home_goals"]).all()


def test_home_win_rate_is_plausible():
    data = ingest.generate_synthetic(seasons=["20222023", "20232024"], seed=3)
    home_rate = data["games"]["home_win"].mean()
    # Real NHL home win rates sit around 0.52-0.56; the generator should match.
    assert 0.50 < home_rate < 0.62
