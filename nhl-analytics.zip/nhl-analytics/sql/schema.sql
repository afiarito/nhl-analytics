-- NHL analytics relational schema (SQLite dialect).
-- Normalised into a teams dimension and two fact tables so the analytical
-- queries can demonstrate joins, aggregation and window functions.

DROP TABLE IF EXISTS team_game_stats;
DROP TABLE IF EXISTS games;
DROP TABLE IF EXISTS teams;

CREATE TABLE teams (
    team_id     INTEGER PRIMARY KEY,
    abbrev      TEXT NOT NULL UNIQUE,
    name        TEXT NOT NULL,
    conference  TEXT NOT NULL,
    division    TEXT NOT NULL
);

CREATE TABLE games (
    game_id       INTEGER PRIMARY KEY,
    season        TEXT NOT NULL,
    game_date     TEXT NOT NULL,
    home_team_id  INTEGER NOT NULL REFERENCES teams(team_id),
    away_team_id  INTEGER NOT NULL REFERENCES teams(team_id),
    home_goals    INTEGER NOT NULL,
    away_goals    INTEGER NOT NULL,
    home_win      INTEGER NOT NULL CHECK (home_win IN (0, 1))
);

CREATE TABLE team_game_stats (
    game_id          INTEGER NOT NULL REFERENCES games(game_id),
    team_id          INTEGER NOT NULL REFERENCES teams(team_id),
    is_home          INTEGER NOT NULL CHECK (is_home IN (0, 1)),
    goals            INTEGER NOT NULL,
    shots            INTEGER NOT NULL,
    hits             INTEGER NOT NULL,
    blocks           INTEGER NOT NULL,
    pp_opportunities INTEGER NOT NULL,
    pp_goals         INTEGER NOT NULL,
    faceoff_win_pct  REAL    NOT NULL,
    giveaways        INTEGER NOT NULL,
    takeaways        INTEGER NOT NULL,
    PRIMARY KEY (game_id, team_id)
);

CREATE INDEX idx_games_season ON games(season);
CREATE INDEX idx_games_home_team ON games(home_team_id);
CREATE INDEX idx_games_away_team ON games(away_team_id);
CREATE INDEX idx_stats_team ON team_game_stats(team_id);
