-- ============================================================================
-- Analytical SQL for the NHL pipeline.
-- Each query is named with a leading "-- name: <key>" marker so queries.py can
-- load them individually. They progress from simple aggregation to multi-CTE
-- window-function analytics.
-- ============================================================================

-- name: standings
-- League standings derived entirely in SQL: 2 points for a win, 1 for a
-- regulation/OT loss decided in extra time is simplified to a straight W/L
-- here. Combines home and away results with a UNION ALL before aggregating.
WITH results AS (
    SELECT home_team_id AS team_id,
           CASE WHEN home_win = 1 THEN 1 ELSE 0 END AS win,
           home_goals AS goals_for,
           away_goals AS goals_against
    FROM games
    UNION ALL
    SELECT away_team_id AS team_id,
           CASE WHEN home_win = 0 THEN 1 ELSE 0 END AS win,
           away_goals AS goals_for,
           home_goals AS goals_against
    FROM games
)
SELECT t.abbrev,
       t.name,
       t.division,
       COUNT(*)                              AS games_played,
       SUM(r.win)                            AS wins,
       COUNT(*) - SUM(r.win)                 AS losses,
       SUM(r.win) * 2                        AS points,
       SUM(r.goals_for)                      AS goals_for,
       SUM(r.goals_against)                  AS goals_against,
       SUM(r.goals_for) - SUM(r.goals_against) AS goal_differential,
       ROUND(1.0 * SUM(r.win) / COUNT(*), 3) AS win_pct
FROM results r
JOIN teams t ON t.team_id = r.team_id
GROUP BY t.team_id
ORDER BY points DESC, goal_differential DESC;

-- name: home_ice_advantage
-- How much does playing at home matter? Aggregated league-wide by season.
SELECT season,
       COUNT(*)                                       AS games,
       SUM(home_win)                                  AS home_wins,
       ROUND(100.0 * SUM(home_win) / COUNT(*), 1)     AS home_win_pct,
       ROUND(AVG(home_goals), 2)                      AS avg_home_goals,
       ROUND(AVG(away_goals), 2)                      AS avg_away_goals
FROM games
GROUP BY season
ORDER BY season;

-- name: team_efficiency
-- Possession and special-teams efficiency per team, joining the box-score
-- fact table back to the teams dimension.
SELECT t.abbrev,
       t.name,
       ROUND(AVG(s.shots), 1)                                   AS avg_shots,
       ROUND(100.0 * SUM(s.goals) / NULLIF(SUM(s.shots), 0), 1) AS shooting_pct,
       ROUND(AVG(s.faceoff_win_pct), 1)                         AS avg_faceoff_pct,
       SUM(s.pp_goals)                                          AS pp_goals,
       SUM(s.pp_opportunities)                                  AS pp_chances,
       ROUND(100.0 * SUM(s.pp_goals) / NULLIF(SUM(s.pp_opportunities), 0), 1) AS pp_pct,
       ROUND(AVG(s.takeaways - s.giveaways), 2)                 AS avg_puck_mgmt
FROM team_game_stats s
JOIN teams t ON t.team_id = s.team_id
GROUP BY t.team_id
ORDER BY pp_pct DESC;

-- name: rolling_form
-- A team's rolling win percentage over its trailing 10 games using a window
-- function over an ordered partition. This is the SQL analogue of the recent
-- form feature the model consumes.
WITH results AS (
    SELECT g.game_id, g.game_date, g.home_team_id AS team_id, g.home_win AS win
    FROM games g
    UNION ALL
    SELECT g.game_id, g.game_date, g.away_team_id AS team_id, 1 - g.home_win AS win
    FROM games g
)
SELECT t.abbrev,
       r.game_date,
       r.win,
       ROUND(
           AVG(r.win) OVER (
               PARTITION BY r.team_id
               ORDER BY r.game_date
               ROWS BETWEEN 9 PRECEDING AND CURRENT ROW
           ), 3
       ) AS rolling_win_pct_10,
       ROW_NUMBER() OVER (PARTITION BY r.team_id ORDER BY r.game_date) AS game_no
FROM results r
JOIN teams t ON t.team_id = r.team_id
ORDER BY t.abbrev, r.game_date;

-- name: biggest_upsets
-- Games where the visiting team won by the largest margin, ranked with a
-- window function and joined to both team names.
WITH away_wins AS (
    SELECT g.game_id,
           g.game_date,
           ht.abbrev AS home_team,
           at.abbrev AS away_team,
           g.away_goals - g.home_goals AS away_margin
    FROM games g
    JOIN teams ht ON ht.team_id = g.home_team_id
    JOIN teams at ON at.team_id = g.away_team_id
    WHERE g.home_win = 0
)
SELECT game_date, away_team, home_team, away_margin,
       RANK() OVER (ORDER BY away_margin DESC) AS upset_rank
FROM away_wins
ORDER BY away_margin DESC
LIMIT 15;
